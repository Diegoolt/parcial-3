import os
from datetime import datetime

# Definir los nombres de los archivos
archivo_productos = 'productos.txt'
archivo_ventas = 'ventas.txt'

# Listas para almacenar productos y ventas
productos = []
ventas = []

# Función para limpiar la consola
def limpiar_consola():
    os.system("cls" if os.name == "nt" else "clear")

# Función para buscar un producto por ID
def buscar_id(id):
    for i, producto in enumerate(productos):
        if producto['id'] == id:
            return i
    return -1

# Función para obtener el siguiente folio
def get_folio():
    if ventas:
        ultimo_folio = ventas[-1]['folio']
        return ultimo_folio + 1
    else:
        return 1001

# Función para leer datos de productos desde un archivo
def leer_productos():
    lista_productos = []
    with open(archivo_productos, 'r') as file:
        for linea in file:
            datos = linea.strip().split(',')
            lista_productos.append({
                'id': datos[0],
                'marca': datos[1],
                'modelo': datos[2],
                'precio': int(datos[3]),
                'stock': int(datos[4])
            })
    return lista_productos

# Función para leer datos de ventas desde un archivo
def leer_ventas():
    lista_ventas = []
    with open(archivo_ventas, 'r') as file:
        for linea in file:
            datos = linea.strip().split(',')
            lista_ventas.append({
                'folio': int(datos[0]),
                'fecha': datos[1],
                'id_producto': datos[2],
                'cantidad': int(datos[3]),
                'total': int(datos[4])
            })
    return lista_ventas

# Función para imprimir datos de productos
def imprimir_datos(lista_datos):
    for producto in lista_datos:
        print(f"{producto['id']}, {producto['marca']}, {producto['modelo']}, {producto['precio']}, {producto['stock']}")

# Función para eliminar un producto por ID
def eliminar_producto_por_id(id):
    indice = buscar_id(id)
    if indice != -1:
        productos.pop(indice)
        return 1
    return -1

# Función para cargar datos desde archivos
def cargar_datos():
    global productos, ventas
    productos = leer_productos()
    ventas = leer_ventas()
    print("Datos cargados correctamente.")
    input("Presione Enter para continuar...")

# Función para respaldar datos a archivos
def respaldar_datos():
    with open(archivo_productos, 'w') as file:
        for producto in productos:
            file.write(f"{producto['id']},{producto['marca']},{producto['modelo']},{producto['precio']},{producto['stock']}\n")
    
    with open(archivo_ventas, 'w') as file:
        for venta in ventas:
            file.write(f"{venta['folio']},{venta['fecha']},{venta['id_producto']},{venta['cantidad']},{venta['total']}\n")
    
    print("Datos respaldados correctamente.")
    input("Presione Enter para continuar...")

# Función para validar datos de productos
def validar_producto(id, marca, modelo, precio, stock):
    if len(id) != 4:
        print("El ID debe tener 4 caracteres.")
        return False
    if buscar_id(id) != -1:
        print("El ID ya existe.")
        return False
    if not marca or not modelo:
        print("La marca y el modelo no deben estar vacíos.")
        return False
    if stock <= 0:
        print("El stock debe ser mayor que 0.")
        return False
    if precio < 0:
        print("El precio debe ser mayor o igual que 0.")
        return False
    return True

# Función para validar fechas
def validar_fecha(fecha):
    if len(fecha) != 10:
        return 1
    try:
        datetime.strptime(fecha, '%d-%m-%Y')
    except ValueError:
        return 1
    return -1

# Función para el menú principal
def menu_principal():
    while True:
        limpiar_consola()
        print("""
        ******************************************
        *       SISTEMA DE VENTAS - MENU         *
        ******************************************
        1. Vender productos
        2. Reportes
        3. Mantenedores
        4. Administración de productos
        5. Salir
        """)
        opcion = input("Ingrese una opción entre 1-5: ")

        if opcion == '1':
            vender_productos()
        elif opcion == '2':
            menu_reportes()
        elif opcion == '3':
            menu_mantenedores()
        elif opcion == '4':
            menu_administracion()
        elif opcion == '5':
            break
        else:
            print("Opción no válida. Intente nuevamente.")
            input("Presione Enter para continuar...")

# Función para vender productos
def vender_productos():
    while True:
        limpiar_consola()
        print("Vender productos\n")
        id_producto = input("Ingrese ID del producto: ").strip()
        indice_producto = buscar_id(id_producto)

        if indice_producto != -1:
            producto = productos[indice_producto]
            print(f"Producto: {producto['marca']} {producto['modelo']}")
            precio_unitario = producto['precio']
            stock_disponible = producto['stock']
            cantidad = int(input("Ingrese cantidad a comprar: "))

            if cantidad <= stock_disponible:
                total = cantidad * precio_unitario
                print(f"Total a pagar por {cantidad} productos: ${total}")
                respuesta = input("¿Desea realizar la compra? (s/n): ")

                if respuesta.lower() == "s":
                    productos[indice_producto]['stock'] -= cantidad
                    nuevo_folio = get_folio()
                    fecha_actual = datetime.now().strftime('%d-%m-%Y')
                    ventas.append({
                        'folio': nuevo_folio,
                        'fecha': fecha_actual,
                        'id_producto': id_producto,
                        'cantidad': cantidad,
                        'total': total
                    })
                    print("¡Venta registrada!")
                else:
                    print("Venta cancelada.")
                
                otra_venta = input("¿Desea comprar otro producto? (s/n): ")
                if otra_venta.lower() != "s":
                    break
            else:
                print("No hay suficiente stock para realizar la venta.")
                input("Presione Enter para continuar...")
        else:
            print(f"Producto con ID '{id_producto}' no encontrado.")
            input("Presione Enter para continuar...")

# Función para el menú de reportes
def menu_reportes():
    while True:
        limpiar_consola()
        print("""
        ******************************************
        *               REPORTES                 *
        ******************************************
        1. General de ventas
        2. Ventas por fecha específica (con total)
        3. Ventas por rango de fecha (con total)
        4. Salir al menú principal
        """)
        op = input("Ingrese una opción (1-4): ")

        if op == '1':
            reporte_general_ventas()
        elif op == '2':
            ventas_por_fecha()
        elif op == '3':
            ventas_por_rango_fecha()
        elif op == '4':
            break
        else:
            print("Opción no válida. Intente nuevamente.")
            input("Presione Enter para continuar...")

# Función para el reporte general de ventas
def reporte_general_ventas():
    if not ventas:
        print("No hay datos que mostrar.")
        input("Presione Enter para continuar...")
        return
    
    total_ventas = sum(venta['total'] for venta in ventas)
    print("Reporte General de Ventas")
    print("-------------------------")
    for venta in ventas:
        print(f"Folio: {venta['folio']}, Fecha: {venta['fecha']}, Producto: {venta['id_producto']}, Cantidad: {venta['cantidad']}, Total: ${venta['total']}")
    print(f"Total ventas: ${total_ventas}")
    input("Presione Enter para continuar...")

# Función para el reporte de ventas por fecha
def ventas_por_fecha():
    fecha = input("Ingrese fecha (dd-mm-yyyy): ").strip()
    if validar_fecha(fecha) == 1:
        print("Fecha inválida.")
        input("Presione Enter para continuar...")
        return

    total_ventas_fecha = 0
    ventas_fecha = [venta for venta in ventas if venta['fecha'] == fecha]

    if not ventas_fecha:
        print("No hay datos que mostrar.")
        input("Presione Enter para continuar...")
        return

    print(f"Reporte de Ventas para la fecha {fecha}")
    print("-------------------------------------")
    for venta in ventas_fecha:
        total_ventas_fecha += venta['total']
        print(f"Folio: {venta['folio']}, Producto: {venta['id_producto']}, Cantidad: {venta['cantidad']}, Total: ${venta['total']}")
    print(f"Total ventas para la fecha {fecha}: ${total_ventas_fecha}")
    input("Presione Enter para continuar...")

# Función para el reporte de ventas por rango de fechas
def ventas_por_rango_fecha():
    fecha_inicio = input("Ingrese fecha de inicio (dd-mm-yyyy): ").strip()
    fecha_fin = input("Ingrese fecha de término (dd-mm-yyyy): ").strip()

    if validar_fecha(fecha_inicio) == 1 or validar_fecha(fecha_fin) == 1:
        print("Fechas inválidas.")
        input("Presione Enter para continuar...")
        return

    total_ventas_rango = 0
    ventas_rango = [venta for venta in ventas if fecha_inicio <= venta['fecha'] <= fecha_fin]

    if not ventas_rango:
        print("No hay datos que mostrar.")
        input("Presione Enter para continuar...")
        return

    print(f"Reporte de Ventas desde {fecha_inicio} hasta {fecha_fin}")
    print("---------------------------------------------")
    for venta in ventas_rango:
        total_ventas_rango += venta['total']
        print(f"Folio: {venta['folio']}, Fecha: {venta['fecha']}, Producto: {venta['id_producto']}, Cantidad: {venta['cantidad']}, Total: ${venta['total']}")
    print(f"Total ventas desde {fecha_inicio} hasta {fecha_fin}: ${total_ventas_rango}")
    input("Presione Enter para continuar...")

# Función para el menú de mantenedores
def menu_mantenedores():
    while True:
        limpiar_consola()
        print("""
        ******************************************
        *              MANTENEDORES              *
        ******************************************
        1. Agregar producto
        2. Buscar producto por código
        3. Eliminar producto por código
        4. Modificar producto por código
        5. Listar todos los productos
        6. Salir al menú principal
        """)
        opcion_2 = input("Ingrese una opción [1-6]: ")

        if opcion_2 == '1':
            agregar_producto()
        elif opcion_2 == '2':
            buscar_producto()
        elif opcion_2 == '3':
            eliminar_producto()
        elif opcion_2 == '4':
            modificar_producto()
        elif opcion_2 == '5':
            listar_productos()
        elif opcion_2 == '6':
            break
        else:
            print("Opción no válida. Intente nuevamente.")
            input("Presione Enter para continuar...")

# Función para agregar un producto
def agregar_producto():
    print("\nAgregar Producto\n")
    id = input("Ingrese código de producto: ")
    marca = input("Ingrese marca del producto: ")
    modelo = input("Ingrese modelo del producto: ")
    precio = int(input("Ingrese precio del producto: "))
    stock = int(input("Ingrese stock del producto: "))
    if validar_producto(id, marca, modelo, precio, stock):
        productos.append({'id': id, 'marca': marca, 'modelo': modelo, 'precio': precio, 'stock': stock})
        print("\nProducto agregado correctamente.")
    else:
        print("Error al agregar el producto.")
    input("Presione Enter para continuar...")

# Función para buscar un producto por ID
def buscar_producto():
    print("\nBuscar Producto por ID\n")
    id = input("Ingrese código de producto: ")
    indice_producto = buscar_id(id)
    if indice_producto != -1:
        producto = productos[indice_producto]
        print(f"Producto encontrado: {producto['marca']} {producto['modelo']}")
        input("Presione Enter para continuar...")
    else:
        print(f"Producto con ID '{id}' no encontrado.")
        input("Presione Enter para continuar...")

# Función para eliminar un producto por ID
def eliminar_producto():
    print("\nEliminar Producto por ID\n")
    id = input("Ingrese código de producto: ")
    if eliminar_producto_por_id(id) != -1:
        print(f"Producto con ID '{id}' eliminado correctamente.")
    else:
        print(f"Producto con ID '{id}' no encontrado.")
    input("Presione Enter para continuar...")

# Función para modificar un producto por ID
def modificar_producto():
    print("\nModificar Producto por ID\n")
    id = input("Ingrese código de producto: ")
    indice_producto = buscar_id(id)
    if indice_producto != -1:
        producto = productos[indice_producto]
        print("Datos actuales del producto:")
        print(f"Código: {producto['id']}")
        print(f"Marca: {producto['marca']}")
        print(f"Modelo: {producto['modelo']}")
        print(f"Precio: ${producto['precio']}")
        print(f"Stock: {producto['stock']}")
        
        nueva_marca = input("Ingrese nueva marca (Enter para mantener): ")
        nuevo_modelo = input("Ingrese nuevo modelo (Enter para mantener): ")
        nuevo_precio = input("Ingrese nuevo precio (Enter para mantener): ")
        nuevo_stock = input("Ingrese nuevo stock (Enter para mantener): ")

        if nueva_marca:
            producto['marca'] = nueva_marca
        if nuevo_modelo:
            producto['modelo'] = nuevo_modelo
        if nuevo_precio:
            producto['precio'] = int(nuevo_precio)
        if nuevo_stock:
            producto['stock'] = int(nuevo_stock)

        print("Producto modificado correctamente.")
        input("Presione Enter para continuar...")
    else:
        print(f"Producto con ID '{id}' no encontrado.")
        input("Presione Enter para continuar...")

# Función para listar todos los productos
def listar_productos():
    print("\nListado de Productos\n")
    if not productos:
        print("No hay productos que mostrar.")
    else:
        imprimir_datos(productos)
    input("Presione Enter para continuar...")

# Función para el menú de administración de productos
def menu_administracion():
    while True:
        limpiar_consola()
        print("""
        ******************************************
        *       ADMINISTRACION DE PRODUCTOS      *
        ******************************************
        1. Cargar datos de productos desde archivo
        2. Respaldar datos de productos a archivo
        3. Observaciones
        4. Regresar al menú principal
        """)
        opcion_3 = input("Ingrese una opción [1-4]: ")

        if opcion_3 == '1':
            cargar_datos()
        elif opcion_3 == '2':
            respaldar_datos()
        elif opcion_3 == '3':
            print("Debe asegurarse de que las listas de productos y ventas no tengan datos antes de cargar desde los archivos.")
            input("Presione Enter para continuar...")
        elif opcion_3 == '4':
            break
        else:
            print("Opción no válida. Intente nuevamente.")
            input("Presione Enter para continuar...")

# Ejecutar el menú principal
menu_principal()
